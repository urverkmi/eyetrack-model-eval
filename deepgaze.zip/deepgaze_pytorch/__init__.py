from .deepgaze1 import DeepGazeI
from .deepgaze2e import DeepGazeIIE
from .deepgaze3 import DeepGazeIII
